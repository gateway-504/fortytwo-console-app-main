# Fortytwo Network Node

For a complete guide on how to download, install, and operate a Fortytwo node, please refer to the official documentation:

**[Fortytwo Node Documentation](https://docs.fortytwo.network/docs/quick-start#/)**
